const db = require('../database/db');
const bcrypt = require('bcryptjs');

class Student {
  static async findByUsername(username) {
    const [rows] = await db.query('SELECT * FROM students WHERE username = ?', [username]);
    return rows[0] || null;
  }

  static async findByEmail(email) {
    const [rows] = await db.query('SELECT * FROM students WHERE email = ?', [email]);
    return rows[0] || null;
  }

  static async findByRollNo(roll_no) {
    const [rows] = await db.query('SELECT * FROM students WHERE roll_no = ?', [roll_no]);
    return rows[0] || null;
  }

  static async findById(id) {
    const [rows] = await db.query('SELECT * FROM students WHERE id = ?', [id]);
    return rows[0] || null;
  }

  static async getAll() {
    const [rows] = await db.query('SELECT id, username, email, full_name, roll_no, department, phone, status, profile_pic, created_at FROM students ORDER BY created_at DESC');
    return rows;
  }

  static async countAll() {
    const [rows] = await db.query('SELECT COUNT(*) as count FROM students');
    return rows[0].count;
  }

  static async countActive() {
    const [rows] = await db.query("SELECT COUNT(*) as count FROM students WHERE status = 'active'");
    return rows[0].count;
  }

  static async create({ username, password, email, full_name, roll_no, department, phone }) {
    const hashedPassword = await bcrypt.hash(password, 10);
    const [result] = await db.query(
      'INSERT INTO students (username, password, email, full_name, roll_no, department, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [username, hashedPassword, email, full_name, roll_no, department, phone, 'active']
    );
    return result.insertId;
  }

  static async updateProfile(id, { full_name, phone, department, profile_pic }) {
    const [result] = await db.query(
      'UPDATE students SET full_name = ?, phone = ?, department = ?, profile_pic = ? WHERE id = ?',
      [full_name, phone, department, profile_pic, id]
    );
    return result.affectedRows > 0;
  }

  static async updateStatus(id, status) {
    const [result] = await db.query(
      'UPDATE students SET status = ? WHERE id = ?',
      [status, id]
    );
    return result.affectedRows > 0;
  }

  static async updatePassword(id, password) {
    const hashedPassword = await bcrypt.hash(password, 10);
    const [result] = await db.query(
      'UPDATE students SET password = ? WHERE id = ?',
      [hashedPassword, id]
    );
    return result.affectedRows > 0;
  }

  static async delete(id) {
    const [result] = await db.query('DELETE FROM students WHERE id = ?', [id]);
    return result.affectedRows > 0;
  }
}

module.exports = Student;
