# AI Chatbot for College Student Support

A complete, responsive web application designed to assist college students with their academic and campus queries. Built using Node.js, Express.js, MySQL, and EJS templates, following standard MVC architectural practices.

---

## Key Features

### 👤 Student Features
- **Register & Secure Login:** Session-based authentication with bcrypt-hashed passwords.
- **Forgot Password Reset:** Verify identity via Roll Number and Email to safely reset login credentials.
- **Interactive Chatbot:** Live conversational bot answering 22 predefined college topics (admissions, fees, exams, timetable, hostel, library, placement cell, training, contact details, and more).
- **Keyword / Semantic Overlap Search:** Matches variations of student queries, providing instant answers or a polite fallback message.
- **Home Dashboard:** Welcome message, campus announcements board, student profile view/editor, preselected avatar settings, and a fully searchable FAQs catalog.

### 🛡️ Admin Management Panel
- **Usage Statistics Dashboard:** Metric cards tracking Total Students, Total FAQs, Total Chat Sessions, Messages Exchanged, and Active Users.
- **Interactive Charts (Chart.js):** Custom graphs visualising daily bot activity, monthly trends, and the most frequently asked student queries.
- **FAQ Database CRUD:** Add, update, search, or delete bot-response records dynamically.
- **Student User Manager:** List student details, activate/deactivate accounts, or permanently delete profiles.
- **Conversations Log Inspector:** Group chats by sessions, filter by student, and view complete message transcripts between students and the chatbot.
- **Campus Announcements publisher:** Publish, edit, and delete news bulletins displayable immediately on all student dashboards.

---

## Predefined FAQ Topics Handled by Chatbot
1. Admission process
2. Fee details
3. Scholarship information
4. College timings
5. Department information
6. Faculty information
7. Semester timetable
8. Exam timetable
9. Internal exams
10. External exams
11. Results
12. Attendance rules
13. Leave process
14. Library timings
15. Library rules
16. Hostel information
17. Transport information
18. Placement cell
19. Training programs
20. Internship information
21. Holidays
22. Contact details

---

## Technology Stack
- **Frontend/Views:** HTML5, CSS3 (Vanilla design with custom layouts, variables, responsive panels), EJS (Embedded JavaScript), Client-side JavaScript.
- **Backend:** Node.js, Express.js
- **Database:** MySQL (via `mysql2/promise` pool)
- **Security & Session:** `express-session` storage, password hashing with `bcryptjs`.
- **Visualization & Design:** Chart.js, FontAwesome Icons.

---

## Installation & Launch Instructions

### Prerequisites
- **Node.js** (v14 or above recommended)
- **MySQL Server** (running locally on port 3306)

### Setup Steps

1. **Extract/Clone Project Files**
   Ensure all files are placed in your working folder.

2. **Configure Database Credentials**
   Open the `.env` file in the root directory. Edit the variables to match your local MySQL configuration:
   ```env
   PORT=3000
   DB_HOST=localhost
   DB_USER=root
   DB_PASS=your_mysql_password
   DB_NAME=college_chatbot
   SESSION_SECRET=college_chatbot_secret_key_2026
   NODE_ENV=development
   ```
   *Note: If your local MySQL root user has no password, leave `DB_PASS` empty (`DB_PASS=`).*

3. **Install Dependencies**
   Open a terminal in the project directory and run:
   ```bash
   npm install
   ```

4. **Run the Application**
   Start the Node server:
   ```bash
   npm start
   ```
   *Note: The application features an **Automatic Database Seeding Utility**. On launch, if the database `college_chatbot` is missing or contains no tables, the server will automatically create the database, establish connection, and execute `db.sql` to load all schemas and test datasets. You do NOT need to manually import any SQL scripts!*

5. **Access the Portal**
   Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

---

## Seed Accounts (For Testing & Review)

### 👤 Student Account
- **Username:** `student`
- **Password:** `admin123`

### 🛡️ Admin Account
- **Username:** `admin`
- **Password:** `admin123`
