module.exports = {
  isStudent: (req, res, next) => {
    if (req.session.user && req.session.role === 'student') {
      return next();
    }
    req.session.redirectUrl = req.originalUrl;
    res.redirect('/');
  },

  isAdmin: (req, res, next) => {
    if (req.session.user && req.session.role === 'admin') {
      return next();
    }
    req.session.redirectUrl = req.originalUrl;
    res.redirect('/');
  },

  isLoggedIn: (req, res, next) => {
    if (req.session.user) {
      if (req.session.role === 'admin') {
        return res.redirect('/admin/dashboard');
      } else if (req.session.role === 'student') {
        return res.redirect('/student/dashboard');
      }
    }
    next();
  },

  apiIsStudent: (req, res, next) => {
    if (req.session.user && req.session.role === 'student') {
      return next();
    }
    return res.status(401).json({ success: false, error: 'Unauthorized. Student session required.' });
  },

  apiIsAdmin: (req, res, next) => {
    if (req.session.user && req.session.role === 'admin') {
      return next();
    }
    return res.status(401).json({ success: false, error: 'Unauthorized. Admin session required.' });
  }
};
