const FAQ = require('../models/FAQ');
const Announcement = require('../models/Announcement');
const Student = require('../models/Student');

exports.showDashboard = async (req, res) => {
  try {
    const faqs = await FAQ.getAll();
    const categories = await FAQ.getCategories();
    const announcements = await Announcement.getAll();
    
    res.render('student/dashboard', {
      user: req.session.user,
      faqs,
      categories,
      announcements,
      currentPage: 'dashboard'
    });
  } catch (error) {
    console.error('Error rendering dashboard:', error);
    res.render('student/dashboard', {
      user: req.session.user,
      faqs: [],
      categories: [],
      announcements: [],
      currentPage: 'dashboard'
    });
  }
};

exports.showChat = (req, res) => {
  res.render('student/chat', {
    user: req.session.user,
    currentPage: 'chat'
  });
};

exports.showAiAssistant = (req, res) => {
  res.render('student/ai-assistant', {
    user: req.session.user,
    currentPage: 'ai-assistant'
  });
};

exports.updateProfile = async (req, res) => {
  try {
    const { full_name, phone, department, profile_pic } = req.body;
    const studentId = req.session.user.id;

    await Student.update(studentId, { full_name, phone, department, profile_pic });

    req.session.user.full_name = full_name;
    req.session.user.phone = phone;
    req.session.user.department = department;
    if (profile_pic) req.session.user.profile_pic = profile_pic;

    res.json({ success: true, message: 'Profile updated successfully!', user: req.session.user });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({ success: false, error: 'Failed to update profile.' });
  }
};
