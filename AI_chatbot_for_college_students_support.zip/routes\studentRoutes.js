const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const chatController = require('../controllers/chatController');
const aiAssistantController = require('../controllers/aiAssistantController');
const { isStudent } = require('../middleware/auth');

// Apply isStudent middleware to student routes
router.use(isStudent);

// Dashboard
router.get('/dashboard', studentController.showDashboard);

// Standard Chat interface
router.get('/chat', studentController.showChat);

// Campus AI Assistant interface & APIs
router.get('/ai-assistant', studentController.showAiAssistant);
router.post('/ai-assistant/chat', aiAssistantController.processChat);
router.get('/ai-assistant/sessions', aiAssistantController.getSessions);
router.get('/ai-assistant/history/:sessionId', aiAssistantController.getSessionMessages);
router.delete('/ai-assistant/clear/:sessionId', aiAssistantController.clearSession);

// Update profile details
router.post('/profile', studentController.updateProfile);

// Chatbot interactions
router.post('/chat', chatController.sendMessage);
router.get('/chat/history/:sessionId', chatController.getSessionHistory);

module.exports = router;
