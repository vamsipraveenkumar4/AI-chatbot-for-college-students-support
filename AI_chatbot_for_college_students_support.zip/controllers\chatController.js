const FAQ = require('../models/FAQ');
const ChatHistory = require('../models/ChatHistory');

exports.sendMessage = async (req, res) => {
  try {
    const { message, sessionId } = req.body;
    const studentId = req.session.user ? req.session.user.id : null;

    if (!message || !sessionId) {
      return res.status(400).json({ success: false, error: 'Message and session ID are required.' });
    }

    // Save student message
    await ChatHistory.logMessage({
      session_id: sessionId,
      student_id: studentId,
      message_text: message,
      sender: 'student'
    });

    // Search FAQs for matching answer
    const matchedFaqs = await FAQ.search(message.trim());
    let reply = "";
    let matchedFaqId = null;

    if (matchedFaqs && matchedFaqs.length > 0) {
      reply = matchedFaqs[0].answer;
      matchedFaqId = matchedFaqs[0].id;
    } else {
      reply = "Thank you for reaching out! I don't have exact details on that specific phrase in my FAQ database right now. Please check our FAQs section or try our Campus AI Assistant for detailed answers!";
    }

    // Save bot reply
    await ChatHistory.logMessage({
      session_id: sessionId,
      student_id: studentId,
      message_text: reply,
      sender: 'bot',
      faq_id: matchedFaqId
    });

    res.json({ success: true, reply, faq_id: matchedFaqId });
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ success: false, error: 'Failed to process chat message.' });
  }
};

exports.getSessionHistory = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const history = await ChatHistory.getSessionHistory(sessionId);
    res.json({ success: true, data: history });
  } catch (error) {
    console.error('Error fetching history:', error);
    res.status(500).json({ success: false, error: 'Failed to retrieve session history.' });
  }
};
