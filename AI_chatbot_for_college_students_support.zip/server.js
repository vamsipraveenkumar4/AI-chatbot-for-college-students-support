const express = require('express');
const session = require('express-session');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
require('dotenv').config();

const db = require('./database/db');
const authRoutes = require('./routes/authRoutes');
const adminRoutes = require('./routes/adminRoutes');
const studentRoutes = require('./routes/studentRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Logging & CORS
app.use(morgan('dev'));
app.use(cors());

// Body Parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session Configuration
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'college_chatbot_secret_key_2026',
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24, // 24 Hours session
      secure: false // Set to true if running over HTTPS
    }
  })
);

// View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static Folders
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Ensure Uploads folder exists
const fs = require('fs');
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

// Global variables for templates
app.use((req, res, next) => {
  res.locals.session = req.session;
  next();
});

// Route Handlers
app.use('/', authRoutes);
app.use('/admin', adminRoutes);
app.use('/student', studentRoutes);

// 404 Handler - render clean error view or redirect
app.use((req, res) => {
  res.status(404).render('error', { 
    error: 'The requested page was not found.',
    user: req.session.user || null 
  });
});

// Database Initialization and Start Server
async function startServer() {
  console.log('Initializing database connection...');
  await db.initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`=====================================================`);
    console.log(`Server is running in ${process.env.NODE_ENV || 'development'} mode`);
    console.log(`URL: http://localhost:${PORT}`);
    console.log(`=====================================================`);
  });
}

startServer();
