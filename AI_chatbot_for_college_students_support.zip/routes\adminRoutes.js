const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const faqController = require('../controllers/faqController');
const { isAdmin } = require('../middleware/auth');

// Apply isAdmin middleware to all admin routes
router.use(isAdmin);

// Dashboard & Stats
router.get('/dashboard', adminController.showDashboard);
router.get('/stats', adminController.getStatsData);

// FAQs CRUD (API and Page Manager)
router.get('/faqs', adminController.showFaqsManager);
router.post('/faqs', faqController.createFaq);
router.put('/faqs/:id', faqController.updateFaq);
router.delete('/faqs/:id', faqController.deleteFaq);

// Student Management (API and Page Manager)
router.get('/students', adminController.showStudentsManager);
router.put('/students/:id/status', adminController.updateStudentStatus);
router.delete('/students/:id', adminController.deleteStudent);

// Announcements (API and Page Manager)
router.get('/announcements', adminController.showAnnouncementsManager);
router.post('/announcements', adminController.createAnnouncement);
router.put('/announcements/:id', adminController.updateAnnouncement);
router.delete('/announcements/:id', adminController.deleteAnnouncement);

// Chat History (API and Page Manager)
router.get('/history', adminController.showChatHistory);
router.get('/history/:sessionId', adminController.getSessionTranscript);

module.exports = router;
