const db = require('../database/db');

class Announcement {
  static async getAll() {
    const [rows] = await db.query(
      `SELECT a.*, adm.username as author 
       FROM announcements a 
       LEFT JOIN admins adm ON a.created_by = adm.id 
       ORDER BY a.created_at DESC`
    );
    return rows;
  }

  static async getRecent(limit = 5) {
    const [rows] = await db.query(
      `SELECT a.*, adm.username as author 
       FROM announcements a 
       LEFT JOIN admins adm ON a.created_by = adm.id 
       ORDER BY a.created_at DESC 
       LIMIT ?`,
      [limit]
    );
    return rows;
  }

  static async findById(id) {
    const [rows] = await db.query('SELECT * FROM announcements WHERE id = ?', [id]);
    return rows[0] || null;
  }

  static async create({ title, content, created_by }) {
    const [result] = await db.query(
      'INSERT INTO announcements (title, content, created_by) VALUES (?, ?, ?)',
      [title, content, created_by]
    );
    return result.insertId;
  }

  static async update(id, { title, content }) {
    const [result] = await db.query(
      'UPDATE announcements SET title = ?, content = ? WHERE id = ?',
      [title, content, id]
    );
    return result.affectedRows > 0;
  }

  static async delete(id) {
    const [result] = await db.query('DELETE FROM announcements WHERE id = ?', [id]);
    return result.affectedRows > 0;
  }
}

module.exports = Announcement;
