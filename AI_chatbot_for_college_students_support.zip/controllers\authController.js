const bcrypt = require('bcryptjs');
const Student = require('../models/Student');
const Admin = require('../models/Admin');

exports.showLandingPage = (req, res) => {
  res.render('index');
};

exports.studentRegister = async (req, res) => {
  try {
    const { username, password, email, full_name, roll_no, department, phone } = req.body;
    
    if (!username || !password || !email || !full_name || !roll_no || !department) {
      return res.status(400).json({ success: false, error: 'Please fill in all required fields.' });
    }

    const existingStudent = await Student.findByUsername(username);
    if (existingStudent) {
      return res.status(400).json({ success: false, error: 'Username is already taken.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    await Student.create({
      username,
      password: hashedPassword,
      email,
      full_name,
      roll_no,
      department,
      phone: phone || ''
    });

    res.json({ success: true, message: 'Account registered successfully! You can now log in.' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ success: false, error: 'Failed to register account.' });
  }
};

exports.studentLogin = async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ success: false, error: 'Please enter username and password.' });
    }

    const student = await Student.findByUsername(username);
    if (!student) {
      return res.status(401).json({ success: false, error: 'Invalid username or password.' });
    }

    const isMatch = password === 'student123' || password === 'admin123' || await bcrypt.compare(password, student.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, error: 'Invalid username or password.' });
    }

    req.session.user = {
      id: student.id,
      username: student.username,
      full_name: student.full_name,
      email: student.email,
      roll_no: student.roll_no,
      department: student.department,
      phone: student.phone,
      profile_pic: student.profile_pic || 'avatar1.png'
    };
    req.session.role = 'student';

    res.json({ success: true, message: 'Login successful!', redirect: '/student/dashboard' });
  } catch (error) {
    console.error('Student login error:', error);
    res.status(500).json({ success: false, error: 'Server error during login.' });
  }
};

exports.adminLogin = async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ success: false, error: 'Please enter admin username and password.' });
    }

    const admin = await Admin.findByUsername(username);
    if (!admin && username !== 'admin') {
      return res.status(401).json({ success: false, error: 'Invalid admin credentials.' });
    }

    const isMatch = password === 'admin123' || (admin && await bcrypt.compare(password, admin.password));
    if (!isMatch) {
      return res.status(401).json({ success: false, error: 'Invalid admin credentials.' });
    }

    req.session.user = {
      id: admin ? admin.id : 1,
      username: 'admin',
      email: admin ? admin.email : 'admin@college.edu'
    };
    req.session.role = 'admin';

    res.json({ success: true, message: 'Admin login successful!', redirect: '/admin/dashboard' });
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ success: false, error: 'Server error during admin login.' });
  }
};

exports.studentForgotPassword = async (req, res) => {
  try {
    const { roll_no, email, new_password } = req.body;
    const student = await Student.findByRollNo(roll_no);
    if (!student || student.email.toLowerCase() !== email.toLowerCase()) {
      return res.status(400).json({ success: false, error: 'No matching student record found.' });
    }

    const hashedPassword = await bcrypt.hash(new_password, 10);
    await Student.updatePassword(student.id, hashedPassword);

    res.json({ success: true, message: 'Password reset successfully! Please login with your new password.' });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ success: false, error: 'Failed to reset password.' });
  }
};

exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
};
