const db = require('../database/db');

class LoginActivity {
  static async logActivity({ user_type, user_id, ip_address, browser }) {
    const [result] = await db.query(
      'INSERT INTO login_activity (user_type, user_id, ip_address, browser) VALUES (?, ?, ?, ?)',
      [user_type, user_id, ip_address, browser]
    );
    return result.insertId;
  }

  static async countActiveUsers(hoursLimit = 24) {
    const [rows] = await db.query(
      `SELECT COUNT(DISTINCT user_id) as count 
       FROM login_activity 
       WHERE user_type = 'student' AND login_time >= DATE_SUB(NOW(), INTERVAL ? HOUR)`,
      [hoursLimit]
    );
    return rows[0].count;
  }

  static async getRecentLogins(limit = 10) {
    const [rows] = await db.query(
      `SELECT la.*, 
              CASE 
                WHEN la.user_type = 'admin' THEN a.username
                WHEN la.user_type = 'student' THEN s.full_name
              END as user_name,
              CASE
                WHEN la.user_type = 'student' THEN s.roll_no
                ELSE 'N/A'
              END as roll_no
       FROM login_activity la
       LEFT JOIN admins a ON la.user_type = 'admin' AND la.user_id = a.id
       LEFT JOIN students s ON la.user_type = 'student' AND la.user_id = s.id
       ORDER BY la.login_time DESC
       LIMIT ?`,
      [limit]
    );
    return rows;
  }
}

module.exports = LoginActivity;
