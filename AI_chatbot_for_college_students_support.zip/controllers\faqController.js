const FAQ = require('../models/FAQ');

exports.createFaq = async (req, res) => {
  try {
    const { question, answer, category } = req.body;
    await FAQ.create({ question, answer, category });
    res.json({ success: true, message: 'FAQ created successfully!' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to create FAQ.' });
  }
};

exports.updateFaq = async (req, res) => {
  try {
    const { id } = req.params;
    const { question, answer, category } = req.body;
    await FAQ.update(id, { question, answer, category });
    res.json({ success: true, message: 'FAQ updated successfully!' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to update FAQ.' });
  }
};

exports.deleteFaq = async (req, res) => {
  try {
    const { id } = req.params;
    await FAQ.delete(id);
    res.json({ success: true, message: 'FAQ deleted successfully!' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to delete FAQ.' });
  }
};
