const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { isLoggedIn } = require('../middleware/auth');

// GET Landing Page
router.get('/', isLoggedIn, authController.showLandingPage);

// GET Campus AI Assistant Alias Route
router.get('/ai-assistant', (req, res) => {
  if (req.session && req.session.user) {
    return res.redirect('/student/ai-assistant');
  }
  res.redirect('/');
});

// POST Student Register
router.post('/register', authController.studentRegister);

// POST Student Login
router.post('/login/student', authController.studentLogin);

// POST Admin Login
router.post('/login/admin', authController.adminLogin);

// POST Student Forgot Password
router.post('/forgot-password', authController.studentForgotPassword);

// GET Logout
router.get('/logout', authController.logout);

module.exports = router;
