// Main JavaScript for common dashboard elements, alerts, mobile toggle, and authentication panels

document.addEventListener('DOMContentLoaded', () => {
  // Mobile Sidebar Toggle
  const menuToggle = document.querySelector('.menu-toggle');
  const sidebar = document.querySelector('.sidebar');
  
  if (menuToggle && sidebar) {
    menuToggle.addEventListener('click', () => {
      sidebar.classList.toggle('active');
    });
    
    // Close sidebar when clicking outside of it on mobile
    document.addEventListener('click', (e) => {
      if (!sidebar.contains(e.target) && !menuToggle.contains(e.target) && sidebar.classList.contains('active')) {
        sidebar.classList.remove('active');
      }
    });
  }

  // Handle Landing Page Tab Switching
  const authTabs = document.querySelectorAll('.auth-tab');
  const formPanels = document.querySelectorAll('.auth-form-panel');
  
  if (authTabs.length > 0) {
    authTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        // Deactivate all tabs
        authTabs.forEach(t => t.classList.remove('active'));
        // Activate current tab
        tab.classList.add('active');
        
        // Hide all panels
        formPanels.forEach(p => p.classList.remove('active'));
        
        // Show selected panel
        const targetPanelId = tab.getAttribute('data-target');
        const targetPanel = document.getElementById(targetPanelId);
        if (targetPanel) {
          targetPanel.classList.add('active');
        }
      });
    });
  }
});

// Helper for rendering client-side success/error alerts
function showAlert(containerId, message, type = 'success') {
  const container = document.getElementById(containerId);
  if (!container) return;

  const iconClass = type === 'success' ? 'fa-circle-check' : 'fa-circle-xmark';
  
  container.innerHTML = `
    <div class="alert alert-${type}">
      <i class="fa-solid ${iconClass}"></i>
      <div>${message}</div>
    </div>
  `;

  // Auto-dismiss alert after 5 seconds
  setTimeout(() => {
    container.innerHTML = '';
  }, 5000);
}
