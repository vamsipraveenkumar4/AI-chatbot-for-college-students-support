const db = require('../database/db');

class ChatHistory {
  static async logMessage({ session_id, student_id, message_text, sender, faq_id = null }) {
    const [result] = await db.query(
      'INSERT INTO chat_history (session_id, student_id, message_text, sender, faq_id) VALUES (?, ?, ?, ?, ?)',
      [session_id, student_id, message_text, sender, faq_id]
    );
    return result.insertId;
  }

  static async getSessionHistory(session_id) {
    const [rows] = await db.query(
      'SELECT * FROM chat_history WHERE session_id = ? ORDER BY created_at ASC',
      [session_id]
    );
    return rows;
  }

  static async getAllSessions() {
    const [rows] = await db.query(
      `SELECT ch.session_id, ch.student_id, s.full_name, s.roll_no, s.department,
              COUNT(ch.id) as message_count,
              MAX(ch.created_at) as last_activity
       FROM chat_history ch
       JOIN students s ON ch.student_id = s.id
       GROUP BY ch.session_id, ch.student_id, s.full_name, s.roll_no, s.department
       ORDER BY last_activity DESC`
    );
    return rows;
  }

  static async countTotalSessions() {
    const [rows] = await db.query('SELECT COUNT(DISTINCT session_id) as count FROM chat_history');
    return rows[0].count;
  }

  static async countTotalMessages() {
    const [rows] = await db.query('SELECT COUNT(*) as count FROM chat_history');
    return rows[0].count;
  }

  static async getDailyUsage(daysLimit = 7) {
    const [rows] = await db.query(
      `SELECT DATE_FORMAT(created_at, '%Y-%m-%d') as date, COUNT(*) as count
       FROM chat_history
       WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
       GROUP BY DATE_FORMAT(created_at, '%Y-%m-%d')
       ORDER BY date ASC`,
      [daysLimit]
    );
    return rows;
  }

  static async getMonthlyUsage() {
    const [rows] = await db.query(
      `SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count
       FROM chat_history
       GROUP BY DATE_FORMAT(created_at, '%Y-%m')
       ORDER BY month ASC`
    );
    return rows;
  }

  static async getMostAskedQuestions(limit = 5) {
    const [rows] = await db.query(
      `SELECT f.question, f.category, COUNT(ch.id) as count
       FROM chat_history ch
       JOIN faqs f ON ch.faq_id = f.id
       WHERE ch.sender = 'student' AND ch.faq_id IS NOT NULL
       GROUP BY ch.faq_id, f.question, f.category
       ORDER BY count DESC
       LIMIT ?`,
      [limit]
    );
    return rows;
  }
}

module.exports = ChatHistory;
