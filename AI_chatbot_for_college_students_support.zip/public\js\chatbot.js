// Student Chatbot Live interface helper

document.addEventListener('DOMContentLoaded', () => {
  const chatHistoryBox = document.getElementById('chat-history');
  const chatInput = document.getElementById('chat-input');
  const sendBtn = document.getElementById('send-btn');
  const typingIndicator = document.getElementById('typing-indicator');
  const chips = document.querySelectorAll('.chip');

  if (!chatHistoryBox) return; // Exit if not in chat window

  // 1. Initialize or load Chat Session ID
  let sessionId = sessionStorage.getItem('chat_session_id');
  if (!sessionId) {
    sessionId = 'sess_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
    sessionStorage.setItem('chat_session_id', sessionId);
  }

  // 2. Load past chat history for session
  loadChatHistory();

  // 3. Setup event listeners
  sendBtn.addEventListener('click', () => {
    sendMessage();
  });

  chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });

  // Chip click handler
  if (chips.length > 0) {
    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        const text = chip.getAttribute('data-question') || chip.innerText.trim();
        chatInput.value = text;
        sendMessage();
      });
    });
  }

  // Load chat history from server
  async function loadChatHistory() {
    try {
      showLoading(true);
      const response = await fetch(`/student/chat/history/${sessionId}`);
      const result = await response.json();
      showLoading(false);

      if (result.success && result.data.length > 0) {
        // Render past messages
        result.data.forEach(msg => {
          appendMessage(msg.message_text, msg.sender, new Date(msg.created_at));
        });
      } else {
        // Welcome message if fresh session
        appendMessage("Hello! I am your College Support Assistant. How can I help you today? You can choose a topic below or type your question.", "bot");
      }
      scrollToBottom();
    } catch (err) {
      console.error('Failed to load chat history:', err);
      showLoading(false);
      appendMessage("Hello! I am your College Support Assistant. How can I help you today? (Note: Failed to load previous chat history from server)", "bot");
    }
  }

  // Send message to server
  async function sendMessage() {
    const text = chatInput.value.trim();
    if (!text) return;

    // Clear input
    chatInput.value = '';
    
    // Append student message
    appendMessage(text, 'student');
    scrollToBottom();

    // Show typing indicator
    typingIndicator.style.display = 'flex';
    chatInput.disabled = true;
    sendBtn.disabled = true;

    try {
      const response = await fetch('/student/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, sessionId })
      });
      const result = await response.json();

      typingIndicator.style.display = 'none';
      chatInput.disabled = false;
      sendBtn.disabled = false;
      chatInput.focus();

      if (result.success) {
        appendMessage(result.reply, 'bot');
      } else {
        appendMessage("Sorry, I encountered a temporary connection issue. Please try again.", 'bot');
      }
      scrollToBottom();
    } catch (err) {
      console.error(err);
      typingIndicator.style.display = 'none';
      chatInput.disabled = false;
      sendBtn.disabled = false;
      appendMessage("Sorry, I encountered a connection error. Please verify your connection and try again.", 'bot');
      scrollToBottom();
    }
  }

  // Helper: Append Message Bubble to UI
  function appendMessage(text, sender, timestamp = new Date()) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `chat-msg ${sender}`;

    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'chat-bubble';
    bubbleDiv.innerText = text;

    const metaDiv = document.createElement('div');
    metaDiv.className = 'chat-meta';
    
    // Format timestamp: hh:mm AM/PM
    const hours = timestamp.getHours();
    const minutes = timestamp.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = hours % 12 || 12;
    const formattedMinutes = minutes < 10 ? '0' + minutes : minutes;
    metaDiv.innerText = `${sender === 'bot' ? 'Assistant' : 'You'} • ${formattedHours}:${formattedMinutes} ${ampm}`;

    msgDiv.appendChild(bubbleDiv);
    msgDiv.appendChild(metaDiv);
    
    // Append to container before typing indicator
    chatHistoryBox.insertBefore(msgDiv, typingIndicator);
  }

  function scrollToBottom() {
    chatHistoryBox.scrollTop = chatHistoryBox.scrollHeight;
  }

  function showLoading(show) {
    // If we want a separate loading spinner inside chat history on load
    if (show) {
      typingIndicator.style.display = 'flex';
    } else {
      typingIndicator.style.display = 'none';
    }
  }
});
