const FAQ = require('../models/FAQ');
const Student = require('../models/Student');
const Announcement = require('../models/Announcement');
const ChatHistory = require('../models/ChatHistory');

exports.showDashboard = async (req, res) => {
  try {
    const totalStudents = await Student.countAll();
    const totalFaqs = await FAQ.countAll();
    const totalSessions = await ChatHistory.countTotalSessions();
    const totalMessages = await ChatHistory.countTotalMessages();

    res.render('admin/dashboard', {
      user: req.session.user,
      stats: { totalStudents, totalFaqs, totalSessions, totalMessages },
      currentPage: 'dashboard'
    });
  } catch (error) {
    console.error(error);
    res.render('admin/dashboard', {
      user: req.session.user,
      stats: { totalStudents: 0, totalFaqs: 0, totalSessions: 0, totalMessages: 0 },
      currentPage: 'dashboard'
    });
  }
};

exports.getStatsData = async (req, res) => {
  res.json({ success: true, daily: [], monthly: [], topQuestions: [] });
};

exports.showFaqsManager = async (req, res) => {
  const faqs = await FAQ.getAll();
  res.render('admin/faqs', { user: req.session.user, faqs, currentPage: 'faqs' });
};

exports.showStudentsManager = async (req, res) => {
  const students = await Student.getAll();
  res.render('admin/students', { user: req.session.user, students, currentPage: 'students' });
};

exports.updateStudentStatus = async (req, res) => {
  res.json({ success: true });
};

exports.deleteStudent = async (req, res) => {
  res.json({ success: true });
};

exports.showAnnouncementsManager = async (req, res) => {
  const announcements = await Announcement.getAll();
  res.render('admin/announcements', { user: req.session.user, announcements, currentPage: 'announcements' });
};

exports.createAnnouncement = async (req, res) => {
  res.json({ success: true });
};

exports.updateAnnouncement = async (req, res) => {
  res.json({ success: true });
};

exports.deleteAnnouncement = async (req, res) => {
  res.json({ success: true });
};

exports.showChatHistory = async (req, res) => {
  const sessions = await ChatHistory.getAllSessions();
  res.render('admin/history', { user: req.session.user, sessions, currentPage: 'history' });
};

exports.getSessionTranscript = async (req, res) => {
  const history = await ChatHistory.getSessionHistory(req.params.sessionId);
  res.json({ success: true, data: history });
};
