const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const { DB_HOST, DB_USER, DB_PASS, DB_NAME } = process.env;

let pool;
let useMock = false;

// Mock database storage for fallback
const mockStore = {
  students: [
    { id: 1, username: 'student', password: '$2a$10$RzV/aP9m1sQvLgX/v07W4Ou6i1uL6pYqL6Vq1hZ3460rDq6985S7W', email: 'student@college.edu', full_name: 'Jane Doe', roll_no: 'CS2026001', department: 'Computer Science & Engineering', phone: '9876543210', status: 'active', profile_pic: 'avatar1.png', created_at: new Date() },
    { id: 2, username: 'student2', password: '$2a$10$RzV/aP9m1sQvLgX/v07W4Ou6i1uL6pYqL6Vq1hZ3460rDq6985S7W', email: 'student2@college.edu', full_name: 'John Smith', roll_no: 'EC2026042', department: 'Electronics & Communication', phone: '9876543211', status: 'active', profile_pic: 'avatar2.png', created_at: new Date() }
  ],
  admins: [
    { id: 1, username: 'admin', password: '$2a$10$RzV/aP9m1sQvLgX/v07W4Ou6i1uL6pYqL6Vq1hZ3460rDq6985S7W', email: 'admin@college.edu', created_at: new Date() }
  ],
  announcements: [
    { id: 1, title: 'Welcome to the New Academic Year', content: 'We are excited to welcome all returning and new students to campus. Classes commence this Wednesday. Please review your semester timetable on the student dashboard.', created_by: 1, author: 'Admin', created_at: new Date() },
    { id: 2, title: 'Mid-Term Examinations Schedule', content: 'The mid-term exams for all departments will commence from the first Monday of next month. Timetables have been posted outside the HOD offices.', created_by: 1, author: 'Admin', created_at: new Date() },
    { id: 3, title: 'Campus Placement Drive - TCS & Infosys', content: 'TCS and Infosys are visiting campus for recruitment on July 25th. Registered final year students must gather in the main auditorium at 9:00 AM.', created_by: 1, author: 'Admin', created_at: new Date() }
  ],
  faqs: [
    { id: 1, category: 'Admission', question: 'How does the admission process work?', answer: 'Admissions are conducted both online and offline. Candidates must register on the college portal, upload required documents (10th/12th marksheets, transfer certificate, category certificate), select their preferred course, and pay the registration fee.' },
    { id: 2, category: 'Fees', question: 'What are the details of the college fees?', answer: 'The annual tuition fee varies by course: B.Tech is $1,200 per semester, B.Sc is $800, and M.Tech is $1,500. Exam fees of $50 per semester are paid separately. Payments can be made via net banking or credit card.' },
    { id: 3, category: 'Scholarships', question: 'What scholarship opportunities are available?', answer: 'We offer Merit Scholarships (for top 5% students), Need-based Financial Aid (for families with annual income < $3,000), and Government/State Scholarships for reserved categories. Applications open in September.' },
    { id: 4, category: 'Timings', question: 'What are the college timings?', answer: 'The college operates from Monday to Friday, 9:00 AM to 4:30 PM. Lunch break is from 12:45 PM to 1:45 PM. The library is open on Saturdays from 9:00 AM to 1:00 PM.' },
    { id: 5, category: 'Departments', question: 'What departments do you have in the college?', answer: 'The college has five major departments: Computer Science & Engineering (CSE), Electronics & Communication Engineering (ECE), Electrical & Electronics Engineering (EEE), Mechanical Engineering (ME), and Civil Engineering (CE).' },
    { id: 6, category: 'Faculty', question: 'Where can I find faculty details?', answer: 'Faculty details, including research domains, contact emails, and cabin numbers are listed under the Faculty directory on the college portal.' },
    { id: 7, category: 'Timetable', question: 'Where is the semester timetable?', answer: 'The semester timetable is uploaded to the student dashboard and displayed on department notice boards at the start of each semester.' },
    { id: 8, category: 'Exams', question: 'When will the exam timetable be released?', answer: 'The final semester exam timetable is published 3 weeks before exams begin on the bulletin board and student portal.' },
    { id: 9, category: 'Exams', question: 'How are internal exams conducted?', answer: 'There are three internal assessment tests conducted per semester (T1, T2, T3). The average of the best two is taken for the final internal marks.' },
    { id: 10, category: 'Attendance', question: 'What are the attendance rules?', answer: 'Students must maintain a minimum of 75% attendance in each subject to be eligible for end-semester exams. Medical condonation up to 10% may be granted for valid medical reasons.' },
    { id: 11, category: 'Library', question: 'What are the library operating hours?', answer: 'The main campus library is open Monday to Friday from 8:30 AM to 7:00 PM, and Saturdays from 9:00 AM to 1:00 PM.' },
    { id: 12, category: 'Placements', question: 'Where is the placement cell and how do I contact them?', answer: 'The Training & Placement Cell is located on the 2nd Floor of Block-C. Contact email: placement@college.edu.' },
    { id: 13, category: 'Hostel', question: 'What are the hostel details and rules?', answer: 'Separate hostels for boys and girls with 24/7 security, Wi-Fi, laundry, and mess serving nutritious meals. Gates close at 8:30 PM.' },
    { id: 14, category: 'Contact', question: 'What are the college contact details?', answer: 'Address: 123 Education Lane, Tech City. Phone: +1 (555) 019-9000. Email: info@college.edu.' }
  ],
  chat_history: []
};

async function initializeDatabase() {
  try {
    const tempConnection = await mysql.createConnection({
      host: DB_HOST || 'localhost',
      user: DB_USER || 'root',
      password: DB_PASS || '',
      connectTimeout: 2000
    });

    await tempConnection.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME || 'college_chatbot'}\``);
    await tempConnection.end();

    pool = mysql.createPool({
      host: DB_HOST || 'localhost',
      user: DB_USER || 'root',
      password: DB_PASS || '',
      database: DB_NAME || 'college_chatbot',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });

    const [tables] = await pool.query('SHOW TABLES');
    if (tables.length === 0) {
      const sqlFilePath = path.join(__dirname, '..', 'db.sql');
      const sqlContent = fs.readFileSync(sqlFilePath, 'utf8');
      const queries = sqlContent
        .split(/;\s*$/m)
        .map(q => q.trim())
        .filter(q => q.length > 0);

      const conn = await pool.getConnection();
      try {
        await conn.beginTransaction();
        for (const query of queries) {
          if (query.toUpperCase().startsWith('USE ')) continue;
          await conn.query(query);
        }
        await conn.commit();
      } catch (err) {
        await conn.rollback();
        console.error('Error during seeding:', err);
      } finally {
        conn.release();
      }
    }
    console.log('Connected to MySQL Database successfully.');
  } catch (error) {
    console.warn('MySQL unavailable. Falling back to local in-memory store mode for smooth execution.', error.message);
    useMock = true;
  }
}

// Fallback executor for mock queries
async function runMockQuery(sql, params = []) {
  const cleanSql = sql.trim().toLowerCase();
  
  if (cleanSql.startsWith('select * from faqs where question like') || cleanSql.includes('from faqs')) {
    if (cleanSql.includes('count(*)')) return [[{ count: mockStore.faqs.length }]];
    if (cleanSql.includes('distinct category')) return [[{ category: 'Admission' }, { category: 'Fees' }, { category: 'Scholarships' }, { category: 'Timings' }, { category: 'Departments' }, { category: 'Exams' }, { category: 'Attendance' }, { category: 'Library' }, { category: 'Placements' }, { category: 'Hostel' }, { category: 'Contact' }]];
    return [mockStore.faqs];
  }
  
  if (cleanSql.includes('from students')) {
    if (cleanSql.includes('where username =')) {
      const user = mockStore.students.find(s => s.username === params[0] || s.email === params[0]);
      return [[user].filter(Boolean)];
    }
    if (cleanSql.includes('where roll_no =')) {
      const user = mockStore.students.find(s => s.roll_no === params[0]);
      return [[user].filter(Boolean)];
    }
    if (cleanSql.includes('where id =')) {
      const user = mockStore.students.find(s => s.id == params[0]);
      return [[user].filter(Boolean)];
    }
    return [mockStore.students];
  }

  if (cleanSql.includes('from admins')) {
    if (cleanSql.includes('where username =')) {
      const admin = mockStore.admins.find(a => a.username === params[0]);
      return [[admin].filter(Boolean)];
    }
    return [mockStore.admins];
  }

  if (cleanSql.includes('from announcements')) {
    return [mockStore.announcements];
  }

  if (cleanSql.includes('insert into chat_history')) {
    const newId = mockStore.chat_history.length + 1;
    const record = {
      id: newId,
      session_id: params[0],
      student_id: params[1],
      message_text: params[2],
      sender: params[3],
      faq_id: params[4] || null,
      created_at: new Date()
    };
    mockStore.chat_history.push(record);
    return [{ insertId: newId, affectedRows: 1 }];
  }

  if (cleanSql.includes('from chat_history')) {
    if (cleanSql.includes('where session_id =')) {
      const msgs = mockStore.chat_history.filter(c => c.session_id === params[0]);
      return [msgs];
    }
    if (cleanSql.includes('count(distinct session_id)')) {
      const sessions = new Set(mockStore.chat_history.map(c => c.session_id));
      return [[{ count: sessions.size || 1 }]];
    }
    if (cleanSql.includes('count(*)')) {
      return [[{ count: mockStore.chat_history.length }]];
    }
    return [mockStore.chat_history];
  }

  if (cleanSql.includes('insert into students')) {
    const newStudent = {
      id: mockStore.students.length + 1,
      username: params[0],
      password: params[1],
      email: params[2],
      full_name: params[3],
      roll_no: params[4],
      department: params[5],
      phone: params[6] || '',
      status: 'active',
      profile_pic: 'avatar1.png',
      created_at: new Date()
    };
    mockStore.students.push(newStudent);
    return [{ insertId: newStudent.id, affectedRows: 1 }];
  }

  if (cleanSql.includes('update students')) {
    const student = mockStore.students.find(s => s.id == params[3] || s.id == params[2]);
    if (student) {
      if (params.length >= 4) {
        student.full_name = params[0];
        student.phone = params[1];
        student.department = params[2];
      }
    }
    return [{ affectedRows: 1 }];
  }

  return [[]];
}

const db = {
  query: async (sql, params) => {
    if (useMock) return runMockQuery(sql, params);
    if (!pool) throw new Error('Database pool not initialized.');
    return pool.query(sql, params);
  },
  execute: async (sql, params) => {
    if (useMock) return runMockQuery(sql, params);
    if (!pool) throw new Error('Database pool not initialized.');
    return pool.execute(sql, params);
  },
  getConnection: async () => {
    if (useMock) {
      return {
        beginTransaction: async () => {},
        commit: async () => {},
        rollback: async () => {},
        release: () => {},
        query: async (sql, params) => runMockQuery(sql, params)
      };
    }
    if (!pool) throw new Error('Database pool not initialized.');
    return pool.getConnection();
  },
  initializeDatabase,
  getMockStore: () => mockStore
};

module.exports = db;

