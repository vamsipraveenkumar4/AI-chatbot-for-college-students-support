const ChatHistory = require('../models/ChatHistory');

// Comprehensive Knowledge Base for College Topics
const collegeKnowledgeBase = {
  admissions: {
    keywords: ['admission', 'admissions', 'apply', 'application', 'eligibility', 'enroll', 'enrollment', 'seat', 'cut off', 'cutoff', 'criteria', 'documents', 'entrance'],
    title: 'Admission Information & Process',
    answer: `Here is the comprehensive information about **College Admissions**:

- **Eligibility Criteria:** Candidates must have completed 10+2 (Higher Secondary) with Physics, Chemistry, and Mathematics (PCM) with a minimum of 60% aggregate marks.
- **Application Process:**
  1. Register online at our portal or visit the Campus Admission Cell in Block-A.
  2. Upload 10th and 12th marksheets, Transfer Certificate (TC), Conduct Certificate, and Passport Photos.
  3. Select your preferred branch (CSE, ECE, EEE, ME, CE, AI & DS).
  4. Pay the registration fee ($50 / ₹1,000).
- **Important Dates:**
  - Online Application Opens: May 15th
  - Application Deadline: July 31st
  - Counseling & Document Verification: August 5th - August 10th
- **Contact Admissions Cell:** Email: \`admissions@college.edu\` | Phone: +1 (555) 019-9001`
  },

  courses: {
    keywords: ['course', 'courses', 'program', 'degree', 'btech', 'b.tech', 'mtech', 'm.tech', 'mca', 'mba', 'bsc', 'undergraduate', 'postgraduate', 'degree options'],
    title: 'Academic Courses & Degree Programs',
    answer: `We offer a wide range of **Undergraduate (UG)** and **Postgraduate (PG)** degree programs:

**1. Undergraduate Programs (B.Tech - 4 Years):**
- B.Tech in Computer Science & Engineering (CSE)
- B.Tech in Artificial Intelligence & Data Science (AI & DS)
- B.Tech in Electronics & Communication Engineering (ECE)
- B.Tech in Electrical & Electronics Engineering (EEE)
- B.Tech in Mechanical Engineering (ME)
- B.Tech in Civil Engineering (CE)

**2. Postgraduate Programs (M.Tech / MBA / MCA - 2 Years):**
- M.Tech in Software Engineering & Data Analytics
- M.Tech in Very Large Scale Integration (VLSI) & Embedded Systems
- Master of Business Administration (MBA - HR, Finance, Marketing)
- Master of Computer Applications (MCA)

All courses are AICTE approved and affiliated with the National Technological University.`
  },

  departments: {
    keywords: ['department', 'departments', 'cse', 'ece', 'eee', 'mechanical', 'civil', 'branch', 'branches', 'engineering dept'],
    title: 'Academic Departments',
    answer: `Our college has 6 premier academic departments equipped with state-of-the-art laboratories and research facilities:

1. **Computer Science & Engineering (CSE):** Features High-Performance AI Labs, Cybersecurity Center, and Cloud Computing Hub.
2. **Electronics & Communication (ECE):** Features Embedded Systems, IoT, Microwave, and VLSI Signal Processing Labs.
3. **Electrical & Electronics (EEE):** Features Power Systems, Smart Grid, Controls, and Electric Vehicle (EV) Labs.
4. **Mechanical Engineering (ME):** Features CAD/CAM Center, Robotics, Thermodynamics, and 3D Printing Workshops.
5. **Civil Engineering (CE):** Features Structural Analysis, Environmental Engineering, and Surveying Labs.
6. **Artificial Intelligence & Data Science (AI & DS):** Specialized in Deep Learning, Computer Vision, and Natural Language Processing.`
  },

  faculty: {
    keywords: ['faculty', 'professor', 'professors', 'hod', 'teacher', 'teachers', 'instructor', 'lecturer', 'staff', 'dean'],
    title: 'Faculty & Department Heads',
    answer: `Our college takes pride in having a distinguished faculty team:

- **Dean of Academics:** Dr. Robert Vance, Ph.D. (IIT Madras) - 25+ years experience in Software Architecture & Distributed Systems.
- **HOD - Computer Science (CSE):** Dr. Aris Thorne, Ph.D. - Specialist in Artificial Intelligence & Machine Learning.
- **HOD - Electronics (ECE):** Dr. Elena Rostova, Ph.D. - Microelectronics & Embedded IoT Systems.
- **HOD - Mechanical (ME):** Prof. David Miller, M.Tech, Ph.D. - Robotics & Industrial Automation.
- **HOD - Electrical (EEE):** Dr. Sarah Jenkins, Ph.D. - Renewable Energy & Smart Grids.

*Faculty Office Hours:* Monday to Friday, 3:30 PM - 4:30 PM in their respective departmental cabins.`
  },

  syllabus: {
    keywords: ['syllabus', 'curriculum', 'subject', 'subjects', 'credit', 'credits', 'semester content', 'course outline'],
    title: 'Syllabus & Course Curriculum',
    answer: `The **Semester Syllabus & Curriculum Structure** follows the Choice-Based Credit System (CBCS):

- **First Year (Sem 1 & 2):** Engineering Mathematics, Applied Physics, Basic Electrical Engineering, Programming in C/Python, Engineering Graphics, Environmental Studies.
- **Second Year (Sem 3 & 4):** Data Structures, Object-Oriented Programming (Java/C++), Digital Logic, Operating Systems, Database Management Systems (DBMS), Discrete Math.
- **Third Year (Sem 5 & 6):** Software Engineering, Computer Networks, Artificial Intelligence, Web Development, Department Electives, Industrial Internship.
- **Fourth Year (Sem 7 & 8):** Cloud Computing, Cybersecurity, Major Capstone Project, Advanced Professional Electives, Entrepreneurship.

Detailed PDF syllabus copies for each semester can be downloaded from the **Student Dashboard** standard downloads tab.`
  },

  attendance: {
    keywords: ['attendance', 'percentage', 'detained', 'condonation', 'leave requirement', 'shortage', '75%', 'present', 'absent'],
    title: 'Attendance Regulations & Minimum Requirements',
    answer: `Important rules regarding **College Attendance**:

- **75% Requirement:** Students MUST maintain a minimum of **75% aggregate attendance** in each subject to be eligible for end-semester examinations.
- **Condonation Policy:** A medical condonation of up to **10%** (bringing requirement down to 65%) can be granted for valid medical reasons or representing the college in sports/cultural events.
- **Attendance Tracking:** Real-time daily attendance is updated on the Student Portal by 5:00 PM every day.
- **Medical Leave Process:** Submit a medical certificate signed by a registered practitioner to your Department HOD within **3 days** of resuming classes.`
  },

  exams: {
    keywords: ['exam', 'exams', 'examination', 'midterm', 'mid term', 'sem exam', 'end sem', 'internal', 'external', 'revaluation', 'backlog', 'hall ticket', 'grade', 'cgpa', 'sgpa'],
    title: 'Examinations, Grading & Assessment',
    answer: `Details on **College Examinations & Evaluation**:

- **Internal Assessments (30 Marks):** 3 Mid-Term Internal Exams (T1, T2, T3) are conducted each semester. The best 2 out of 3 marks are averaged.
- **End-Semester External Exam (70 Marks):** Written theory and practical lab exams held at the end of each 6-month term.
- **Grading System:**
  - O (Outstanding): 90-100% | 10 Grade Points
  - A+ (Excellent): 80-89% | 9 Grade Points
  - A (Very Good): 70-79% | 8 Grade Points
  - B+ (Good): 60-69% | 7 Grade Points
  - F (Fail): Below 40% (Re-examination required)
- **Hall Tickets:** Downloadable from the Student Portal 5 days before exams for students meeting 75% attendance.`
  },

  timetable: {
    keywords: ['timetable', 'schedule', 'class timing', 'routine', 'period', 'lab schedule', 'lecture time', 'break'],
    title: 'Class Timetable & Daily Schedule',
    answer: `Standard **College Schedule & Class Timetable**:

- **College Operating Hours:** Monday to Friday, 9:00 AM to 4:30 PM.
- **Daily Period Breakdown:**
  - Period 1: 09:00 AM – 10:00 AM
  - Period 2: 10:00 AM – 11:00 AM
  - *Tea Break:* 11:00 AM – 11:15 AM
  - Period 3: 11:15 AM – 12:15 PM
  - Period 4: 12:15 PM – 01:00 PM
  - *Lunch Break:* 01:00 PM – 01:45 PM
  - Period 5 & 6 (Lab Sessions / Seminars): 01:45 PM – 04:30 PM

Specific branch/section timetables are posted on classroom noticeboards and downloadable under **Student Dashboard**.`
  },

  placements: {
    keywords: ['placement', 'placements', 'job', 'jobs', 'package', 'salary', 'recruiter', 'recruiters', 'tcs', 'infosys', 'wipro', 'microsoft', 'google', 'training cell', 'career'],
    title: 'Campus Placements & Career Cell',
    answer: `Our **Training & Placement Cell (TPC)** ensures outstanding career opportunities:

- **Placement Statistics:**
  - Placement Rate: **92.5%** for eligible students
  - Highest Package: **$45,000 / ₹42 LPA** (Microsoft & Amazon)
  - Average Package: **$8,500 / ₹7.2 LPA**
- **Top Recruiters:** TCS, Infosys, Wipro, Cognizant, Microsoft, Amazon, Accenture, Capgemini, L&T, Tech Mahindra.
- **Training Programs:** Aptitude building, Data Structures & Coding bootcamps, Mock Interviews, Resume writing, and GD preparation starting from 3rd year.
- **Placement Cell Location:** Block-C, 2nd Floor | Email: \`placement@college.edu\``
  },

  scholarships: {
    keywords: ['scholarship', 'scholarships', 'financial aid', 'fee waiver', 'reimbursement', 'stipend', 'merit scholarship', 'concession'],
    title: 'Scholarships & Financial Aid',
    answer: `We provide substantial **Financial Support & Scholarships**:

1. **Merit Scholarship:** 50% tuition fee waiver for top 5 ranking students in university semester exams.
2. **Sports Scholarship:** 25% to 100% fee concession for state and national level sports achievements.
3. **Economically Weaker Section (EWS) Aid:** Financial assistance for families with annual income < $3,500.
4. **Government Schemes:** Full support for State Post-Matric Scholarships and Central Sector Scholarship applications.

*How to Apply:* Submit the filled scholarship form at the Accounts Counter (Block-A) along with income and marks certificates by September 15th.`
  },

  library: {
    keywords: ['library', 'book', 'books', 'borrow', 'journal', 'journals', 'reading room', 'e-library', 'digital library', 'fine'],
    title: 'Central Library Facilities',
    answer: `The **Central Library & Information Resource Center**:

- **Timings:** Monday – Friday: 08:00 AM – 08:00 PM | Saturday: 09:00 AM – 02:00 PM (Extended till 10:00 PM during exams).
- **Holdings:** 65,000+ Physical Books, 3,500+ E-Journals (IEEE, Springer, ScienceDirect), ACM Digital Library.
- **Borrowing Rules:**
  - Students can borrow up to **4 books** for **14 days**.
  - Late return fine: $0.20 / ₹5 per day per book.
- **Facilities:** Air-conditioned quiet study rooms, High-speed Wi-Fi, Discussion rooms, OPAC computer terminals.`
  },

  campus_facilities: {
    keywords: ['facility', 'facilities', 'hostel', 'canteen', 'cafeteria', 'sports', 'gym', 'wifi', 'wi-fi', 'bus', 'transport', 'medical', 'hospital', 'auditorium', 'lab', 'labs'],
    title: 'Campus Facilities & Infrastructure',
    answer: `Key **Campus Infrastructure & Facilities**:

- **Hostels:** Separate modern hostels for boys and girls with 24/7 security, Wi-Fi, laundry, and hygienic dining mess.
- **Cafeteria & Food Court:** Serves healthy multi-cuisine meals, snacks, fresh juices, and coffee from 8 AM to 7 PM.
- **Sports & Gym:** Full-size football/cricket ground, basketball courts, indoor badminton arena, and fully equipped gymnasium.
- **Transport Fleet:** 25+ AC and non-AC buses connecting all major routes across the city.
- **Campus Wi-Fi:** 1 Gbps optical fiber campus-wide Wi-Fi network.
- **Medical Center:** Resident doctor and qualified nurse available 24/7 with emergency ambulance on standby.`
  },

  contact: {
    keywords: ['contact', 'phone', 'email', 'address', 'location', 'reach', 'map', 'helpline', 'office', 'number'],
    title: 'Contact Information & Location',
    answer: `Get in touch with **College Administration**:

- **Main Campus Address:** 123 Education Lane, Tech City Campus, Knowledge Zone - 500081.
- **General Inquiry Phone:** +1 (555) 019-9000 / +1 (555) 019-9001
- **Email Contacts:**
  - General Queries: \`info@college.edu\`
  - Admissions: \`admissions@college.edu\`
  - Examination Cell: \`exams@college.edu\`
  - Training & Placements: \`placement@college.edu\`
- **Working Hours:** Monday to Saturday, 9:00 AM to 5:00 PM.`
  }
};

// Check if message is related to college topics
function analyzeQuery(userQuery) {
  const queryLower = userQuery.toLowerCase().trim();
  
  // List of college terms for broad filtering
  const collegeGeneralTerms = [
    'college', 'campus', 'university', 'student', 'class', 'academic', 'principal', 
    'registration', 'semester', 'grade', 'marks', 'department', 'course', 'fee', 
    'admission', 'hostel', 'library', 'exam', 'placement', 'syllabus', 'faculty', 
    'canteen', 'transport', 'bus', 'attendance', 'scholarship', 'result', 'timetable', 
    'hi', 'hello', 'hey', 'help', 'good morning', 'good afternoon', 'good evening',
    'who are you', 'what can you do', 'menu', 'options', 'topics'
  ];

  // Match against specific topic keywords
  let matchedTopic = null;
  let maxScore = 0;

  for (const [key, topic] of Object.entries(collegeKnowledgeBase)) {
    let score = 0;
    for (const kw of topic.keywords) {
      if (queryLower.includes(kw)) {
        score += kw.length; // weight longer keyword matches
      }
    }
    if (score > maxScore) {
      maxScore = score;
      matchedTopic = topic;
    }
  }

  if (matchedTopic && maxScore > 0) {
    return { isCollegeRelated: true, topic: matchedTopic };
  }

  // Greeting or general intro check
  if (['hi', 'hello', 'hey', 'greetings', 'help', 'who are you', 'what can you do'].some(g => queryLower.startsWith(g) || queryLower === g)) {
    return {
      isCollegeRelated: true,
      topic: {
        title: 'Welcome to Campus AI Assistant',
        answer: `Hello! 👋 I am your dedicated **Campus AI Assistant**. I am here to answer all your questions about our college!

You can ask me about:
- **Admissions** & Application steps
- **Courses** (UG/PG) & **Departments**
- **Syllabus** & **Exams**
- **Attendance rules** & **Timetables**
- **Placements** & **Scholarships**
- **Library** & **Campus Facilities** (Hostel, Transport, Cafeteria)
- **Contact Information**

How can I help you today?`
      }
    };
  }

  // Broad check using general college terms
  const hasCollegeTerm = collegeGeneralTerms.some(term => queryLower.includes(term));
  if (hasCollegeTerm) {
    return {
      isCollegeRelated: true,
      topic: {
        title: 'College Information',
        answer: `Thank you for reaching out! Regarding college details:

Our campus provides complete support for all students across admissions, course curriculum, exam schedules, attendance tracking, placements, hostels, and library access.

Feel free to ask a specific question such as *"What is the admission eligibility?"*, *"When are mid-term exams?"*, or *"What packages do recruiters offer?"*!`
      }
    };
  }

  // Off-topic refusal response
  return {
    isCollegeRelated: false,
    topic: {
      title: 'College AI Assistant - Scope Notice',
      answer: `I am the **Campus AI Assistant**, designed specifically to help with college-related queries such as admissions, courses, departments, faculty, syllabus, attendance, exams, timetable, placements, scholarships, library, campus facilities, and contact information.

Please feel free to ask any question related to our college!`
    }
  };
}

// Controller Actions
exports.processChat = async (req, res) => {
  try {
    const { message, sessionId } = req.body;
    const studentId = req.session.user ? req.session.user.id : null;

    if (!message || !message.trim()) {
      return res.status(400).json({ success: false, error: 'Please enter a message.' });
    }

    const activeSessionId = sessionId || ('ai_sess_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7));

    // Save student message to chat history
    await ChatHistory.logMessage({
      session_id: activeSessionId,
      student_id: studentId,
      message_text: message,
      sender: 'student'
    });

    // Analyze query & generate answer
    const analysis = analyzeQuery(message);
    const replyText = analysis.topic.answer;

    // Save AI response to chat history
    await ChatHistory.logMessage({
      session_id: activeSessionId,
      student_id: studentId,
      message_text: replyText,
      sender: 'bot'
    });

    res.json({
      success: true,
      sessionId: activeSessionId,
      reply: replyText,
      isCollegeRelated: analysis.isCollegeRelated,
      title: analysis.topic.title,
      timestamp: new Date()
    });
  } catch (error) {
    console.error('AI Assistant process error:', error);
    res.status(500).json({ success: false, error: 'Failed to process query.' });
  }
};

exports.getSessions = async (req, res) => {
  try {
    const db = require('../database/db');
    let sessions = [];

    if (req.session.user) {
      const studentId = req.session.user.id;
      const [rows] = await db.query(
        `SELECT session_id, MIN(created_at) as started_at, MAX(created_at) as last_activity,
                (SELECT message_text FROM chat_history WHERE session_id = ch.session_id AND sender = 'student' ORDER BY created_at ASC LIMIT 1) as title
         FROM chat_history ch
         WHERE student_id = ? AND session_id LIKE 'ai_sess_%'
         GROUP BY session_id
         ORDER BY last_activity DESC`,
        [studentId]
      );
      sessions = rows;
    }
    
    res.json({ success: true, sessions });
  } catch (error) {
    console.error('Error fetching AI sessions:', error);
    res.json({ success: true, sessions: [] });
  }
};

exports.getSessionMessages = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const history = await ChatHistory.getSessionHistory(sessionId);
    res.json({ success: true, messages: history });
  } catch (error) {
    console.error('Error fetching session messages:', error);
    res.status(500).json({ success: false, error: 'Failed to load messages.' });
  }
};

exports.clearSession = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const db = require('../database/db');
    await db.query('DELETE FROM chat_history WHERE session_id = ?', [sessionId]);
    res.json({ success: true, message: 'Session history cleared.' });
  } catch (error) {
    console.error('Error clearing session:', error);
    res.status(500).json({ success: false, error: 'Failed to clear session.' });
  }
};
