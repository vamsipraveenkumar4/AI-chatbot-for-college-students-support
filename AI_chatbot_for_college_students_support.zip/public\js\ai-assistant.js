// Campus AI Assistant Client Engine

document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('ai-messages-container');
  const chatInput = document.getElementById('ai-chat-input');
  const sendBtn = document.getElementById('ai-send-btn');
  const typingIndicator = document.getElementById('ai-typing-indicator');
  const welcomeCard = document.getElementById('ai-welcome-card');
  const initialLoader = document.getElementById('ai-initial-loader');
  const newChatBtn = document.getElementById('new-chat-btn');
  const sessionsList = document.getElementById('ai-sessions-list');
  const clearTopBtn = document.getElementById('clear-chat-top-btn');
  const clearSidebarBtn = document.getElementById('clear-all-sessions-btn');
  const copyToast = document.getElementById('ai-copy-toast');
  const historyToggleBtn = document.getElementById('ai-history-toggle');
  const historyCloseBtn = document.getElementById('ai-history-close');
  const historySidebar = document.getElementById('ai-history-sidebar');

  if (!container) return; // Exit if not on AI Assistant page

  let currentSessionId = sessionStorage.getItem('campus_ai_session_id');
  if (!currentSessionId) {
    currentSessionId = generateSessionId();
    sessionStorage.setItem('campus_ai_session_id', currentSessionId);
  }

  // Initial setup
  init();

  function init() {
    loadSessionsList();
    if (currentSessionId) {
      loadSessionMessages(currentSessionId);
    }
    setupEventListeners();
  }

  function generateSessionId() {
    return 'ai_sess_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
  }

  function setupEventListeners() {
    // Send button click
    sendBtn.addEventListener('click', handleSend);

    // Auto-expand textarea & Enter to send
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    });

    chatInput.addEventListener('input', () => {
      chatInput.style.height = 'auto';
      chatInput.style.height = Math.min(chatInput.scrollHeight, 100) + 'px';
    });

    // Topic chips click
    document.querySelectorAll('.topic-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const query = chip.getAttribute('data-query');
        chatInput.value = query;
        handleSend();
      });
    });

    // New Chat button
    newChatBtn.addEventListener('click', startNewChat);

    // Clear Chat buttons
    if (clearTopBtn) clearTopBtn.addEventListener('click', clearCurrentChat);
    if (clearSidebarBtn) clearSidebarBtn.addEventListener('click', clearCurrentChat);

    // Mobile Sidebar Drawer toggles
    if (historyToggleBtn) {
      historyToggleBtn.addEventListener('click', () => {
        historySidebar.classList.toggle('active');
      });
    }

    if (historyCloseBtn) {
      historyCloseBtn.addEventListener('click', () => {
        historySidebar.classList.remove('active');
      });
    }
  }

  async function handleSend() {
    const text = chatInput.value.trim();
    if (!text) return;

    // Reset textarea
    chatInput.value = '';
    chatInput.style.height = 'auto';

    // Hide welcome card
    if (welcomeCard) welcomeCard.style.display = 'none';

    // Render User Message
    appendMessage(text, 'user');
    scrollToBottom();

    // Show Typing indicator
    showTyping(true);
    setControlsDisabled(true);

    try {
      const response = await fetch('/student/ai-assistant/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, sessionId: currentSessionId })
      });

      const data = await response.json();
      showTyping(false);
      setControlsDisabled(false);

      if (data.success) {
        currentSessionId = data.sessionId;
        sessionStorage.setItem('campus_ai_session_id', currentSessionId);
        appendMessage(data.reply, 'bot', new Date(data.timestamp));
        loadSessionsList();
      } else {
        appendMessage("I encountered a temporary connection issue. Please try asking again.", 'bot');
      }
      scrollToBottom();
    } catch (err) {
      console.error(err);
      showTyping(false);
      setControlsDisabled(false);
      appendMessage("Network connection error. Please verify your connection and try again.", 'bot');
      scrollToBottom();
    }
  }

  function appendMessage(text, sender, timestamp = new Date()) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `ai-msg ${sender}`;

    const avatarDiv = document.createElement('div');
    avatarDiv.className = 'ai-msg-avatar';
    avatarDiv.innerHTML = sender === 'bot' ? '<i class="fa-solid fa-robot"></i>' : '<i class="fa-solid fa-user"></i>';

    const contentDiv = document.createElement('div');
    contentDiv.className = 'ai-msg-content';

    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'ai-msg-bubble';
    
    // Simple markdown to HTML conversion (bold, lists, code)
    bubbleDiv.innerHTML = formatMarkdown(text);

    const metaDiv = document.createElement('div');
    metaDiv.className = 'ai-msg-meta';

    const timeStr = timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    metaDiv.innerHTML = `<span>${sender === 'bot' ? 'Campus AI Assistant' : 'You'} • ${timeStr}</span>`;

    if (sender === 'bot') {
      const copyBtn = document.createElement('button');
      copyBtn.className = 'copy-msg-btn';
      copyBtn.innerHTML = '<i class="fa-regular fa-copy"></i> Copy';
      copyBtn.addEventListener('click', () => copyToClipboard(text, copyBtn));
      metaDiv.appendChild(copyBtn);
    }

    contentDiv.appendChild(bubbleDiv);
    contentDiv.appendChild(metaDiv);

    msgDiv.appendChild(avatarDiv);
    msgDiv.appendChild(contentDiv);

    container.insertBefore(msgDiv, typingIndicator);
  }

  function formatMarkdown(str) {
    if (!str) return '';
    let formatted = str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // Bold **text**
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // Code `code`
    formatted = formatted.replace(/`(.*?)`/g, '<code style="background: #e2e8f0; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 0.85rem;">$1</code>');

    // Bullet points (- or *)
    const lines = formatted.split('\n');
    let inList = false;
    let result = '';

    lines.forEach(line => {
      const trimmed = line.trim();
      if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        if (!inList) {
          result += '<ul style="margin-left: 20px; margin-top: 6px; margin-bottom: 6px;">';
          inList = true;
        }
        result += `<li>${trimmed.substring(2)}</li>`;
      } else {
        if (inList) {
          result += '</ul>';
          inList = false;
        }
        result += line ? `<p style="margin-bottom: 6px;">${line}</p>` : '<br>';
      }
    });

    if (inList) result += '</ul>';
    return result;
  }

  async function loadSessionsList() {
    try {
      const res = await fetch('/student/ai-assistant/sessions');
      const data = await res.json();

      if (data.success && data.sessions.length > 0) {
        sessionsList.innerHTML = '';
        data.sessions.forEach(sess => {
          const item = document.createElement('div');
          item.className = `ai-session-item ${sess.session_id === currentSessionId ? 'active' : ''}`;
          const title = sess.title ? (sess.title.length > 25 ? sess.title.substring(0, 25) + '...' : sess.title) : 'Chat Session';
          item.innerHTML = `<i class="fa-regular fa-message"></i> <span>${title}</span>`;
          
          item.addEventListener('click', () => {
            currentSessionId = sess.session_id;
            sessionStorage.setItem('campus_ai_session_id', currentSessionId);
            loadSessionMessages(currentSessionId);
            loadSessionsList();
            if (historySidebar) historySidebar.classList.remove('active');
          });

          sessionsList.appendChild(item);
        });
      } else {
        sessionsList.innerHTML = '<div class="ai-session-loading">No past sessions found</div>';
      }
    } catch (err) {
      console.error('Failed to load sessions:', err);
      sessionsList.innerHTML = '<div class="ai-session-loading">Start a chat to see history</div>';
    }
  }

  async function loadSessionMessages(sessionId) {
    try {
      showInitialLoader(true);
      const res = await fetch(`/student/ai-assistant/history/${sessionId}`);
      const data = await res.json();
      showInitialLoader(false);

      // Clear existing message bubbles except typing indicator & welcome card
      document.querySelectorAll('.ai-msg').forEach(el => el.remove());

      if (data.success && data.messages.length > 0) {
        if (welcomeCard) welcomeCard.style.display = 'none';
        data.messages.forEach(msg => {
          appendMessage(msg.message_text, msg.sender, new Date(msg.created_at));
        });
        scrollToBottom();
      } else {
        if (welcomeCard) welcomeCard.style.display = 'block';
      }
    } catch (err) {
      console.error(err);
      showInitialLoader(false);
    }
  }

  function startNewChat() {
    currentSessionId = generateSessionId();
    sessionStorage.setItem('campus_ai_session_id', currentSessionId);
    
    // Clear message bubbles
    document.querySelectorAll('.ai-msg').forEach(el => el.remove());
    if (welcomeCard) welcomeCard.style.display = 'block';
    
    loadSessionsList();
    if (historySidebar) historySidebar.classList.remove('active');
    chatInput.focus();
  }

  async function clearCurrentChat() {
    if (!currentSessionId) return;

    try {
      await fetch(`/student/ai-assistant/clear/${currentSessionId}`, { method: 'DELETE' });
      document.querySelectorAll('.ai-msg').forEach(el => el.remove());
      if (welcomeCard) welcomeCard.style.display = 'block';
      loadSessionsList();
      showToast('Chat history cleared!');
    } catch (err) {
      console.error(err);
    }
  }

  function copyToClipboard(text, btnElement) {
    navigator.clipboard.writeText(text).then(() => {
      btnElement.innerHTML = '<i class="fa-solid fa-check" style="color: var(--success-color);"></i> Copied!';
      showToast('Copied to clipboard!');
      setTimeout(() => {
        btnElement.innerHTML = '<i class="fa-regular fa-copy"></i> Copy';
      }, 2000);
    }).catch(err => {
      console.error('Clipboard copy failed:', err);
    });
  }

  function showToast(msg) {
    if (!copyToast) return;
    copyToast.innerHTML = `<i class="fa-solid fa-check"></i> ${msg}`;
    copyToast.classList.add('show');
    setTimeout(() => {
      copyToast.classList.remove('show');
    }, 2500);
  }

  function scrollToBottom() {
    container.scrollTop = container.scrollHeight;
  }

  function showTyping(show) {
    typingIndicator.style.display = show ? 'flex' : 'none';
  }

  function showInitialLoader(show) {
    if (initialLoader) initialLoader.style.display = show ? 'flex' : 'none';
  }

  function setControlsDisabled(disabled) {
    chatInput.disabled = disabled;
    sendBtn.disabled = disabled;
    if (!disabled) chatInput.focus();
  }
});
