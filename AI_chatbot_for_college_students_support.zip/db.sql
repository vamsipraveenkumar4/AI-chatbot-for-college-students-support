-- Database creation script for AI Chatbot for College Student Support
CREATE DATABASE IF NOT EXISTS college_chatbot;
USE college_chatbot;

-- Admin Table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Student Table
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    roll_no VARCHAR(50) UNIQUE NOT NULL,
    department VARCHAR(100) NOT NULL,
    phone VARCHAR(15),
    status ENUM('active', 'inactive') DEFAULT 'active',
    profile_pic VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- FAQs Table
CREATE TABLE IF NOT EXISTS faqs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(255) NOT NULL,
    answer TEXT NOT NULL,
    category VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Announcements Table
CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL
);

-- Chat History Table
CREATE TABLE IF NOT EXISTS chat_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    student_id INT DEFAULT NULL,
    message_text TEXT NOT NULL,
    sender ENUM('student', 'bot') NOT NULL,
    faq_id INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (faq_id) REFERENCES faqs(id) ON DELETE SET NULL
);

-- Login Activity Table
CREATE TABLE IF NOT EXISTS login_activity (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_type ENUM('admin', 'student') NOT NULL,
    user_id INT NOT NULL,
    ip_address VARCHAR(45),
    browser VARCHAR(255),
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed Data

-- Hashed password for 'admin123' and 'student123' (both are set to $2a$10$RzV/aP9m1sQvLgX/v07W4Ou6i1uL6pYqL6Vq1hZ3460rDq6985S7W)
-- Actually, let's generate two distinct bcrypt hashes.
-- 'admin123' bcrypt hash: $2a$10$RzV/aP9m1sQvLgX/v07W4Ou6i1uL6pYqL6Vq1hZ3460rDq6985S7W
-- 'student123' bcrypt hash: $2b$10$lY1T12h/q3o7rQ.mG5u3yOa5oU95E1.Fh67p9dM4y3lZ4D71z/y6S (let's use the same admin123 hash for simplicity, or we will handle dynamic validation. Same hash $2a$10$RzV/aP9m1sQvLgX/v07W4Ou6i1uL6pYqL6Vq1hZ3460rDq6985S7W works fine as 'admin123' for password)

INSERT INTO admins (username, password, email) VALUES
('admin', '$2a$10$RzV/aP9m1sQvLgX/v07W4Ou6i1uL6pYqL6Vq1hZ3460rDq6985S7W', 'admin@college.edu')
ON DUPLICATE KEY UPDATE id=id;

INSERT INTO students (username, password, email, full_name, roll_no, department, phone, status) VALUES
('student', '$2a$10$RzV/aP9m1sQvLgX/v07W4Ou6i1uL6pYqL6Vq1hZ3460rDq6985S7W', 'student@college.edu', 'Jane Doe', 'CS2026001', 'Computer Science & Engineering', '9876543210', 'active'),
('student2', '$2a$10$RzV/aP9m1sQvLgX/v07W4Ou6i1uL6pYqL6Vq1hZ3460rDq6985S7W', 'student2@college.edu', 'John Smith', 'EC2026042', 'Electronics & Communication', '9876543211', 'active')
ON DUPLICATE KEY UPDATE id=id;

-- Seed announcements
INSERT INTO announcements (title, content, created_by) VALUES
('Welcome to the New Academic Year', 'We are excited to welcome all returning and new students to campus. Classes commence this Wednesday. Please review your semester timetable on the student dashboard.', 1),
('Mid-Term Examinations Schedule', 'The mid-term exams for all departments will commence from the first Monday of next month. Timetables have been posted outside the HOD offices and are available in the Exam Timetable section of the chatbot.', 1),
('Campus Placement Drive - TCS & Infosys', 'TCS and Infosys are visiting campus for recruitment on July 25th. Registered final year students must gather in the main auditorium at 9:00 AM in formal attire with copies of their resumes.', 1);

-- Seed FAQs for all 22 required categories
INSERT INTO faqs (question, answer, category) VALUES
-- 1. Admission process
('How does the admission process work?', 'Admissions are conducted both online and offline. Candidates must register on the college portal, upload required documents (10th/12th marksheets, transfer certificate, category certificate), select their preferred course, and pay the registration fee. Shortlisted students will be called for document verification and fee payment.', 'Admission'),

-- 2. Fee details
('What are the details of the college fees?', 'The annual tuition fee varies by course: B.Tech is $1,200 per semester, B.Sc is $800, and M.Tech is $1,500. Exam fees of $50 per semester are paid separately. Payments can be made via net banking, credit/debit card, or challan at the campus bank counter.', 'Fees'),

-- 3. Scholarship information
('What scholarship opportunities are available?', 'We offer Merit Scholarships (for top 5% students in university exams), Need-based Financial Aid (for families with annual income < $3,000), and Government/State Scholarships for reserved categories. Applications open in September; contact the admin block block-A for details.', 'Scholarships'),

-- 4. College timings
('What are the college timings?', 'The college operates from Monday to Friday, 9:00 AM to 4:30 PM. There is a lunch break from 12:45 PM to 1:45 PM. The library is open on Saturdays from 9:00 AM to 1:00 PM.', 'Timings'),

-- 5. Department information
('What departments do you have in the college?', 'The college has five major departments: Computer Science & Engineering (CSE), Electronics & Communication Engineering (ECE), Electrical & Electronics Engineering (EEE), Mechanical Engineering (ME), and Civil Engineering (CE). Each department has dedicated laboratories and seminar halls.', 'Departments'),

-- 6. Faculty information
('Where can I find faculty details?', 'Faculty details, including their research domains, contact emails, and office cabin numbers, are listed under the "Faculty" page of the college website. You can also query specific faculty details by visiting the department HOD office.', 'Faculty'),

-- 7. Semester timetable
('Where is the semester timetable?', 'The semester timetable is generated by each department and uploaded to the student dashboard. Physical copies are also displayed on the department notice boards at the start of each semester.', 'Timetable'),

-- 8. Exam timetable
('When will the exam timetable be released?', 'The final semester exam timetable is published by the Controller of Examinations 3 weeks before the exams begin. It is displayed on the main bulletin board and made available on the student portal.', 'Exams'),

-- 9. Internal exams
('How are internal exams conducted?', 'There are three internal assessment tests conducted per semester (T1, T2, T3). The average of the best two is taken for the final internal marks (out of 30). Attendance is mandatory for internal assessments.', 'Exams'),

-- 10. External exams
('What are the rules for external end-semester exams?', 'End-semester external exams carry 70 marks. Students must have a minimum of 75% attendance to receive their hall tickets. Bringing mobile phones or unauthorized materials into the examination hall is strictly prohibited.', 'Exams'),

-- 11. Results
('When and where are semester results declared?', 'Semester results are declared within 30 to 45 days after the final exam. Students can view their marksheet and CGPA on the online Student Portal using their Roll Number and Password.', 'Results'),

-- 12. Attendance rules
('What are the attendance rules?', 'Students must maintain a minimum of 75% attendance in each subject to be eligible to write the end-semester examinations. Medical leave condonation of up to 10% may be granted for valid medical reasons upon producing certificates.', 'Attendance'),

-- 13. Leave process
('What is the process for applying for leave?', 'For short leave (1-2 days), submit a written application signed by parents to your class coordinator. For medical leave exceeding 3 days, submit a medical certificate along with the leave form to the HOD within 3 days of returning.', 'Leave'),

-- 14. Library timings
('What are the library operating hours?', 'The main campus library is open Monday to Friday from 8:30 AM to 7:00 PM, and on Saturdays from 9:00 AM to 1:00 PM. During exam periods, the library remains open until 9:00 PM.', 'Library'),

-- 15. Library rules
('What are the rules of the library?', 'Students can borrow up to 4 books for a period of 14 days. A fine of $0.50 per day is charged for late returns. Silence must be maintained at all times. Reference books and journals cannot be taken out of the library.', 'Library'),

-- 16. Hostel information
('What are the hostel details and rules?', 'We have separate hostels for boys and girls with 24/7 security, Wi-Fi, laundry, and a mess serving nutritious meals. Hostel gates close at 8:30 PM. Inmates must seek prior permission from the Warden for night outs.', 'Hostel'),

-- 17. Transport information
('Is college transport available?', 'Yes, the college runs a fleet of buses covering all major parts of the city. Students can apply for a bus pass at the accounts office. The bus route chart and timings are posted on the transport notice board.', 'Transport'),

-- 18. Placement cell
('Where is the placement cell and how do I contact them?', 'The Training & Placement Cell is located on the 2nd Floor of Block-C. It is headed by the Placement Director and coordinates all campus recruitment drives. You can contact them at placement@college.edu.', 'Placements'),

-- 19. Training programs
('What training programs does the college offer?', 'We offer technical coding bootcamps, soft skills development workshops, mock interview sessions, and aptitude training starting from the 3rd year onwards to prepare students for campus placements.', 'Placements'),

-- 20. Internship information
('How do I apply for internships?', 'Students can apply for internships through the placement cell portal or seek external internships. Prior approval (NOC) must be obtained from the department HOD to count the internship for course credit.', 'Placements'),

-- 21. Holidays
('Where can I see the list of holidays?', 'The official academic calendar lists all scheduled holidays, national festivals, and vacation periods. It is distributed to students at the beginning of the academic year and can be downloaded from the college website.', 'Holidays'),

-- 22. Contact details
('What are the college contact details?', 'Address: 123 Education Lane, Campus Drive, Tech City. Phone: +1 (555) 019-9000. Email: info@college.edu. For admission-related queries, email admissions@college.edu.', 'Contact');

-- Seed Chat History for visual charts
-- Inserting messages spread across a few days to simulate daily usage
-- Admin dashboard uses chat_history to count: Total Chat Sessions (unique sessions), Total Messages (total records), Daily Chatbot Usage (count per day)
-- Most asked questions (top count of faq_id)
INSERT INTO chat_history (session_id, student_id, message_text, sender, faq_id, created_at) VALUES
('sess_1', 1, 'Tell me about the admission process', 'student', 1, DATE_SUB(NOW(), INTERVAL 3 DAY)),
('sess_1', 1, 'Admissions are conducted both online and offline...', 'bot', 1, DATE_SUB(NOW(), INTERVAL 3 DAY)),
('sess_1', 1, 'where is the placement cell?', 'student', 18, DATE_SUB(NOW(), INTERVAL 3 DAY)),
('sess_1', 1, 'The Training & Placement Cell is located on the 2nd Floor...', 'bot', 18, DATE_SUB(NOW(), INTERVAL 3 DAY)),

('sess_2', 2, 'what are the fees?', 'student', 2, DATE_SUB(NOW(), INTERVAL 2 DAY)),
('sess_2', 2, 'The annual tuition fee varies...', 'bot', 2, DATE_SUB(NOW(), INTERVAL 2 DAY)),
('sess_2', 2, 'how do I apply for scholarship?', 'student', 3, DATE_SUB(NOW(), INTERVAL 2 DAY)),
('sess_2', 2, 'We offer Merit Scholarships...', 'bot', 3, DATE_SUB(NOW(), INTERVAL 2 DAY)),

('sess_3', 1, 'how does attendance work?', 'student', 12, DATE_SUB(NOW(), INTERVAL 1 DAY)),
('sess_3', 1, 'Students must maintain a minimum of 75%...', 'bot', 12, DATE_SUB(NOW(), INTERVAL 1 DAY)),
('sess_3', 1, 'when is the exam timetable?', 'student', 8, DATE_SUB(NOW(), INTERVAL 1 DAY)),
('sess_3', 1, 'The final semester exam timetable...', 'bot', 8, DATE_SUB(NOW(), INTERVAL 1 DAY)),

('sess_4', 2, 'what are the library hours?', 'student', 14, NOW()),
('sess_4', 2, 'The main campus library is open...', 'bot', 14, NOW()),
('sess_4', 2, 'can you tell me about hostels?', 'student', 16, NOW()),
('sess_4', 2, 'We have separate hostels for...', 'bot', 16, NOW()),
('sess_4', 2, 'invalid query that fails', 'student', NULL, NOW()),
('sess_4', 2, 'Sorry, I don\'t have information about that. Please contact the college office or administrator.', 'bot', NULL, NOW());

-- Seed Login Activity
INSERT INTO login_activity (user_type, user_id, ip_address, browser) VALUES
('student', 1, '127.0.0.1', 'Chrome - Windows 11'),
('student', 2, '127.0.0.1', 'Firefox - Windows 11'),
('admin', 1, '127.0.0.1', 'Chrome - Windows 11'),
('student', 1, '127.0.0.1', 'Chrome - Windows 11');
