const db = require('../database/db');

class FAQ {
  static async getAll() {
    const [rows] = await db.query('SELECT * FROM faqs ORDER BY category, question');
    return rows;
  }

  static async countAll() {
    const [rows] = await db.query('SELECT COUNT(*) as count FROM faqs');
    return rows[0].count;
  }

  static async findById(id) {
    const [rows] = await db.query('SELECT * FROM faqs WHERE id = ?', [id]);
    return rows[0] || null;
  }

  static async create({ question, answer, category }) {
    const [result] = await db.query(
      'INSERT INTO faqs (question, answer, category) VALUES (?, ?, ?)',
      [question, answer, category]
    );
    return result.insertId;
  }

  static async update(id, { question, answer, category }) {
    const [result] = await db.query(
      'UPDATE faqs SET question = ?, answer = ?, category = ? WHERE id = ?',
      [question, answer, category, id]
    );
    return result.affectedRows > 0;
  }

  static async delete(id) {
    const [result] = await db.query('DELETE FROM faqs WHERE id = ?', [id]);
    return result.affectedRows > 0;
  }

  static async search(term) {
    const queryTerm = `%${term}%`;
    const [rows] = await db.query(
      'SELECT * FROM faqs WHERE question LIKE ? OR answer LIKE ? OR category LIKE ?',
      [queryTerm, queryTerm, queryTerm]
    );
    return rows;
  }

  static async getCategories() {
    const [rows] = await db.query('SELECT DISTINCT category FROM faqs ORDER BY category');
    return rows.map(r => r.category);
  }
}

module.exports = FAQ;
